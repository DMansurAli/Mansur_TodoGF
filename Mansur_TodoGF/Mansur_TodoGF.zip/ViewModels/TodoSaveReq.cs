﻿namespace Mansur_TodoGF.ViewModels
{
    public class TodoSaveReq
    {
        public int id { get; set; }
        public string descriptions { get; set; }
    }
}
